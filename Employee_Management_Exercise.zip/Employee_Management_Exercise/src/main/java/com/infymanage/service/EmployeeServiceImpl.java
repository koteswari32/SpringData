package com.infymanage.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.infymanage.domain.Employee;
import com.infymanage.dto.AddressDTO;
import com.infymanage.dto.EmployeeDTO;
import com.infymanage.repository.EmployeeRepository;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeRepository employeeRepository;

	//To add Employee
	@Override
	public void insertEmployee(EmployeeDTO employeeDTO) {
		
		System.out.println("Inserting Employee Details: ");
		
		employeeRepository.save(EmployeeDTO.prepareEmployeeEntity(employeeDTO));
	}
    
	//To get Employee by ID
	@Override
	public EmployeeDTO getEmployeeById(int empId) {
		
		Optional<Employee> optionalEmployee=employeeRepository.findById(empId);
		Employee employeeEntity=new Employee();
		if(optionalEmployee.isPresent()) {
			employeeEntity=optionalEmployee.get();
		}
		
		return Employee.prepareEmployeeDTO(employeeEntity);
	}

	//To get All employees
	@Override
	public List<EmployeeDTO> getAllEmployees() {
		Iterable<Employee> employeeEntities=employeeRepository.findAll();
		
		List<EmployeeDTO> employeeDTO=new ArrayList<>();
		for(Employee e:employeeEntities) {
			
			employeeDTO.add(Employee.prepareEmployeeDTO(e));
		}
		
		return employeeDTO;
	}

	//Update Operation
	@Override
	public EmployeeDTO editEmployee(EmployeeDTO e) {
		
		Optional<Employee> optinalEmployee=employeeRepository.findById(e.getEmpId());
		Employee employeeEntity=new Employee();
		if(optinalEmployee.isPresent()) {
			employeeEntity=optinalEmployee.get();
			employeeEntity.setEmpId(e.getEmpId());
			employeeEntity.setEmpName(e.getEmpName());
			employeeEntity.setDepartment(e.getDepartment());
			employeeEntity.setBaseLocation(e.getBaseLocation());
			employeeEntity.setAddress(AddressDTO.prepareAddressEntity(e.getAddressDto()));
			
			employeeRepository.save(employeeEntity);
			
			
		}
		return Employee.prepareEmployeeDTO(employeeEntity);
	}

	//Delete Operation
	@Override
	public EmployeeDTO removeEmployee(int id) {
		Optional<Employee> opt=employeeRepository.findById(id);
		Employee emp=new Employee();
		if(opt.isPresent()) {
			emp=opt.get();
			employeeRepository.delete(emp);
			
		}
		
		return Employee.prepareEmployeeDTO(emp);
	}

	// To get the 3 employees for page
	@Override
	public Page<Employee> findingAll(Pageable pageable) {
		
		System.out.println("Employee is fetching: ");
		
		Page<Employee> p=employeeRepository.findAll(pageable);
		return p;
	}

	//Sorting the employee based on name
	@Override
	public List<EmployeeDTO> findSortedAll(Sort sort) {
		
		List<Employee> sortedEmployees=employeeRepository.findAll(sort);
		List<EmployeeDTO> emp=new ArrayList<>();
		
		for(Employee e:sortedEmployees) {
			emp.add(Employee.prepareEmployeeDTO(e));
		}
		
		
		return emp;
	}
	

	
	
	
	
	

}
