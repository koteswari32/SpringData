package com.infymanage.service;

import com.infymanage.dto.AddressDTO;

public interface AddressService {

	public void insertAddress(AddressDTO addressDTO);
}
