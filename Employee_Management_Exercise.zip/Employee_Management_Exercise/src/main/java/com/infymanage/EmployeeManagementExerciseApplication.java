package com.infymanage;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.infymanage.domain.Employee;
import com.infymanage.dto.AddressDTO;
import com.infymanage.dto.EmployeeDTO;
import com.infymanage.repository.EmployeeRepository;
import com.infymanage.service.AddressService;
import com.infymanage.service.EmployeeService;

@SpringBootApplication
public class EmployeeManagementExerciseApplication implements CommandLineRunner{

	@Autowired
	ApplicationContext context;
	
	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	AddressService addressService;
	
	@Autowired
	EmployeeRepository repository;
	
	
	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementExerciseApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Log logger = LogFactory.getLog(getClass());
		
		//comment this once table is created 
		AddressDTO address1=new AddressDTO(101,"Guntur","522414");
		AddressDTO address2=new AddressDTO(102,"Dachepalli","522412");
		AddressDTO address3=new AddressDTO(103,"Hyderabad","522132");
		AddressDTO address4=new AddressDTO(104,"Uppal","522133");
		AddressDTO address5=new AddressDTO(105,"Pocharam","522134");
		AddressDTO address6=new AddressDTO(106,"Madinapadu","522135");
		
		EmployeeDTO employee1=new EmployeeDTO("koteswari","ADM","hyd",address1);
		EmployeeDTO employee2=new EmployeeDTO("Bhavani","EAIS","hyd",address2);
		EmployeeDTO employee3=new EmployeeDTO("Kamala","ADM","hyd",address3);
		EmployeeDTO employee4=new EmployeeDTO("Venkata","EAIS","hyd",address4);
		EmployeeDTO employee5=new EmployeeDTO("Abhay","ADM","hyd",address5);
		EmployeeDTO employee6=new EmployeeDTO("Dileep","ADM","hyd",address6);
		
//		addressService.insertAddress(address1);
//		addressService.insertAddress(address2);
//		addressService.insertAddress(address3);
//		addressService.insertAddress(address4);
//		addressService.insertAddress(address5);
//		addressService.insertAddress(address6);
		
		employeeService.insertEmployee(employee1);
		employeeService.insertEmployee(employee2);
		employeeService.insertEmployee(employee3);
		employeeService.insertEmployee(employee4);
		employeeService.insertEmployee(employee5);
		employeeService.insertEmployee(employee6);
		
		logger.info("Records added Successfully ");
		
		
		//Pagination
		
		int k=(int) (repository.count()/3);
		for(int i=0;i<=k;i++) {
			Pageable pageable=PageRequest.of(i, 3);
			logger.info("Records are: ");
			Iterable<Employee> emp=employeeService.findingAll(pageable);
			for(Employee e:emp) {
				logger.info(e);
			}
		}
		
		//Sorting
		
		logger.info("Sorted Records based on name: ");
		
		Iterable<EmployeeDTO> sorted=employeeService.findSortedAll(Sort.by(Sort.Direction.DESC,"empName"));
		for(EmployeeDTO e:sorted) {
			logger.info(e);
		}
		
		
		
		
		
		//Fetch employee by Id
		
		
	logger.info("Let's print the details of Employee: ");
		
		EmployeeDTO employeeDTO=employeeService.getEmployeeById(2);
		logger.info("Employee Id: "+employeeDTO.getEmpId());
		logger.info("Employee Name: "+employeeDTO.getEmpName());
		logger.info("Employee Department: "+employeeDTO.getDepartment());
		logger.info("Employee BaseLocation: "+employeeDTO.getBaseLocation());
		logger.info("Employee Adddress: "+employeeDTO.getAddressDto());
		
//		logger.info("Let's print the All the employees");
//		
//		List<EmployeeDTO> employees=employeeService.getAllEmployees(
//		for(EmployeeDTO e:employees) {
//			logger.info("Employee Id: "+e.getEmpId());
//			logger.info("Employee Name: "+e.getEmpName());
//			logger.info("Employee Department: "+e.getDepartment());
//			logger.info("Employee BaseLocation: "+e.getBaseLocation());
//			logger.info("Employee Adddress: "+e.getAddressDto());
//		}
		
		
//		logger.info("Update the employee record");
//		//To edit the employee details
//		EmployeeDTO employee3=new EmployeeDTO(1,"Kamala","cse","hyd",address1);
//		EmployeeDTO updated=employeeService.editEmployee(employee3);
//		logger.info("Employee Id: "+updated.getEmpId());
//		logger.info("Employee Name: "+updated.getEmpName());
//		logger.info("Employee Department: "+updated.getDepartment());
//		logger.info("Employee BaseLocation"+updated.getBaseLocation());
//		logger.info("Employee Address"+updated.getAddressDto());
//		
//		logger.info("Delete the Employee based on empId:1 ");
//		
//		EmployeeDTO deleted=employeeService.removeEmployee(1);
//		logger.info("Deleted employee Id: "+deleted.getEmpId());
//		logger.info("Deleted employee name: "+deleted.getEmpName());
//		
		
	}

}
