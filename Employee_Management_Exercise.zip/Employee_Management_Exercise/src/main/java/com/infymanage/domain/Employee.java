package com.infymanage.domain;

import com.infymanage.dto.EmployeeDTO;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;



@Entity
public class Employee {
	    @Id// empId is the primary key
	    @GeneratedValue(strategy=GenerationType.IDENTITY)
	    private int empId;
	    private String empName;
	    private String department;
	    private String baseLocation;
	    
	    @OneToOne(cascade=CascadeType.ALL)
	    @JoinColumn(name="address_id",unique=true)
	    private Address address;


		public Employee() {
	    	
	    }
	    
		public Employee(int empId, String empName, String department, String baseLocation, Address address) {
			super();
			this.empId = empId;
			this.empName = empName;
			this.department = department;
			this.baseLocation = baseLocation;
			this.address = address;
		}
	
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
		public String getBaseLocation() {
			return baseLocation;
		}
		public void setBaseLocation(String baseLocation) {
			this.baseLocation = baseLocation;
		}
		public Address getAddress() {
			return address;
		}
		public void setAddress(Address address) {
			this.address = address;
		}
		@Override
		public String toString() {
			return "Employee [empId=" + empId + ", empName=" + empName + ", department=" + department
					+ ", baseLocation=" + baseLocation + ", address=" + address + "]";
		}
	    
	    public static EmployeeDTO prepareEmployeeDTO(Employee employee) {
	    	EmployeeDTO employeeDTO=new EmployeeDTO();
	    	employeeDTO.setEmpId(employee.getEmpId());
	    	employeeDTO.setEmpName(employee.getEmpName());
	    	employeeDTO.setDepartment(employee.getDepartment());
	    	employeeDTO.setBaseLocation(employee.getBaseLocation());
	    	
	    	//here static method is accessed by class Address
	    	employeeDTO.setAddressDto(Address.prepareAddressDTO(employee.getAddress()));
	    	return employeeDTO;
	    }
	

}
