package com.infymanage.dto;

import com.infymanage.domain.Employee;


public class EmployeeDTO {
	
	    private int empId;
	    private String empName;
	    private String department;
	    private String baseLocation;
	    private AddressDTO addressDto;

		public EmployeeDTO() {
	    	
	    }
		
		
	    
		public EmployeeDTO(String empName, String department, String baseLocation, AddressDTO addressDto) {
			super();
			this.empName = empName;
			this.department = department;
			this.baseLocation = baseLocation;
			this.addressDto = addressDto;
		}



		public EmployeeDTO(int empId, String empName, String department, String baseLocation, AddressDTO addressDto) {
			
			this.empId = empId;
			this.empName = empName;
			this.department = department;
			this.baseLocation = baseLocation;
			this.addressDto = addressDto;
		}
		
		
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
		public String getBaseLocation() {
			return baseLocation;
		}
		public void setBaseLocation(String baseLocation) {
			this.baseLocation = baseLocation;
		}
		public AddressDTO getAddressDto() {
			return addressDto;
		}
		public void setAddressDto(AddressDTO addressDto) {
			this.addressDto = addressDto;
		}
		@Override
		public String toString() {
			return "EmployeeDTO [empId=" + empId + ", empName=" + empName + ", department=" + department
					+ ", baseLocation=" + baseLocation + ", addressDto=" + addressDto + "]";
		}
		
		
		public static Employee prepareEmployeeEntity(EmployeeDTO employeeDTO) {
			Employee employeeEntity = new Employee();
			employeeEntity.setEmpId(employeeDTO.getEmpId());
			employeeEntity.setEmpName(employeeDTO.getEmpName());
			employeeEntity.setDepartment(employeeDTO.getDepartment());
			employeeEntity.setBaseLocation(employeeDTO.getBaseLocation());
			
			//static method is accessed by calss name
		    employeeEntity.setAddress(AddressDTO.prepareAddressEntity(employeeDTO.getAddressDto()));
			
			return employeeEntity;
		}
		
	
	    
	    

}
