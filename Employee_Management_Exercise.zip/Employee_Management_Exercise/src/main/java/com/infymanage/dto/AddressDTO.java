package com.infymanage.dto;

import com.infymanage.domain.Address;

public class AddressDTO {
	
	private int addressId;
	private String city;
	private String pincode;
	
	public AddressDTO() {
		
	}
	public AddressDTO(int addressId, String city, String pincode) {
		super();
		this.addressId = addressId;
		this.city = city;
		this.pincode = pincode;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "AddressDTO [addressId=" + addressId + ", city=" + city + ", pincode=" + pincode + "]";
	}
	
	public static Address prepareAddressEntity(AddressDTO addressDTO) {
		Address address=new Address();
		address.setAddressId(addressDTO.getAddressId());
		address.setCity(addressDTO.getCity());
		address.setPincode(addressDTO.getPincode());
		
		return address;
		
	}
	
	

}
