package com.infosys.domain;

import com.infosys.domain.Address;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Employee")
//name starts with the entity class name followed by the method name from the EmployeeRepository separated by a dot.
@NamedQuery(name="Employee.getEmployeeByEmail",query="select emp from Employee emp where emp.employeeEmailId=:emailId")

public class Employee {
      @Id
      @GeneratedValue(strategy=GenerationType.IDENTITY)
	   private Integer empId;
	    private String empName;
	    private String department;
	    private String baseLocation;
	    private double employeeSalary;
	    private String employeeBandLevel;
	    @Column(name="employeecontactnumber")
	    private String employeeContactNumber;
	    @Column(name="employeeemailid")
	    private String employeeEmailId;
	    
		@OneToOne(cascade=CascadeType.ALL)
	    @JoinColumn(name="address_id",unique=true)
	    private Address address;
		
        public Employee() {
	    	
	    }
	    public Employee (Integer empId,String empName, String department, String baseLocation, double employeeSalary,
				String employeeBandLevel, String employeeContactNumber, Address address) {
			super();
			this.empId = empId;
			this.empName = empName;
			this.department = department;
			this.baseLocation = baseLocation;
			this.employeeSalary = employeeSalary;
			this.employeeBandLevel = employeeBandLevel;
			this.employeeContactNumber = employeeContactNumber;
			this.address = address;
		}
	    
	    
		public Employee(Integer empId, String empName, String department, String baseLocation, double employeeSalary,
				String employeeBandLevel, String employeeContactNumber, String employeeEmailId, Address address) {
			super();
			this.empId = empId;
			this.empName = empName;
			this.department = department;
			this.baseLocation = baseLocation;
			this.employeeSalary = employeeSalary;
			this.employeeBandLevel = employeeBandLevel;
			this.employeeContactNumber = employeeContactNumber;
			this.employeeEmailId = employeeEmailId;
			this.address = address;
		}
		public String getEmployeeEmailId() {
			return employeeEmailId;
		}
		public void setEmployeeEmailId(String employeeEmailId) {
			this.employeeEmailId = employeeEmailId;
		}
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(Integer empId) {
			this.empId = empId;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
		public String getBaseLocation() {
			return baseLocation;
		}
		public void setBaseLocation(String baseLocation) {
			this.baseLocation = baseLocation;
		}
		public double getEmployeeSalary() {
			return employeeSalary;
		}
		public void setEmployeeSalary(double employeeSalary) {
			this.employeeSalary = employeeSalary;
		}
		public String getEmployeeBandLevel() {
			return employeeBandLevel;
		}
		public void setEmployeeBandLevel(String employeeBandLevel) {
			this.employeeBandLevel = employeeBandLevel;
		}
		public String getEmployeeContactNumber() {
			return employeeContactNumber;
		}
		public void setEmployeeContactNumber(String employeeContactNumber) {
			this.employeeContactNumber = employeeContactNumber;
		}
		public Address getAddress() {
			return address;
		}
		public void setAddress(Address address) {
			this.address = address;
		}
		@Override
		public String toString() {
			return "Employee [empId=" + empId + ", empName=" + empName + ", department=" + department
					+ ", baseLocation=" + baseLocation + ", employeeSalary=" + employeeSalary + ", employeeBandLevel="
					+ employeeBandLevel + ", employeeContactNumber=" + employeeContactNumber + ", employeeEmailId="
					+ employeeEmailId + ", address=" + address + "]";
		}
	    
	    
}
