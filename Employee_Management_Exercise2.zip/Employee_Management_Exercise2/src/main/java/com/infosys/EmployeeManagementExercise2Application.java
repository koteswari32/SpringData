package com.infosys;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.infosys.domain.Address;
import com.infosys.domain.Employee;
import com.infosys.service.AddressService;
import com.infosys.service.EmployeeService;


@SpringBootApplication
public class EmployeeManagementExercise2Application implements CommandLineRunner{

	
	
	@Autowired
	ApplicationContext context;
	
	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	AddressService addressService;

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementExercise2Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Log logger=LogFactory.getLog(getClass());
		
		Address address1=new Address(111,"Guntur","522414");
		Address address2=new Address(112,"Dachepalli","522412");
		Address address3=new Address(113,"Hyderabad","522132");
		Address address4=new Address(114,"Uppal","522133");
		Address address5=new Address(115,"Pocharam","522134");
		Address address6=new Address(116,"Madinapadu","522135");
		
		Employee employee1=new Employee(1,"Koteswari","ADM","hyd",30000.0,"A","9908251289","koteswari@gmail.com",address1);
		Employee employee2=new Employee(2,"Bhavani","EAIS","hyd",35000.0,"B","9908251280","bhavani@gmail.com",address2);
		Employee employee3=new Employee(3,"Kamala","ADM","hyd",33000.0,"C","9908251281","kamala@gmail.com",address3);
		Employee employee4=new Employee(4,"Venkata","EAIS","hyd",32000.0,"B","9908251282","venkata@gmail.com",address4);
		Employee employee5=new Employee(5,"Abhay","ADM","hyd",31000.0,"C","9908251283","abhay@gmail.com",address5);
		Employee employee6=new Employee(6,"Dileep","ADM","hyd",28000.0,"A","9908251284","dileep@gmail.com",address6);
		
		//Not required
//		addressService.insertAddress(address1);
//		addressService.insertAddress(address2);
//		addressService.insertAddress(address3);
//		addressService.insertAddress(address4);
//		addressService.insertAddress(address5);
//		addressService.insertAddress(address6);
		
		employeeService.insertEmployee(employee1);
		employeeService.insertEmployee(employee2);
		employeeService.insertEmployee(employee3);
		employeeService.insertEmployee(employee4);
		employeeService.insertEmployee(employee5);
		employeeService.insertEmployee(employee6);
		
       logger.info("Employee Details Added succefully");
       
       
//        logger.info("Fetching employee details based on Address:");
//       
//         Employee employee=employeeService.getEmployee(address6);
//         logger.info(employee);
      
//       logger.info("Updating the Employee salary based on Employee Brand level: ");
//      
//        List<Employee> emp=employeeService.getAllEmployees();
//        for(Employee e:emp) {
//    	   logger.info(e);
//      }
       
//       logger.info("Getting Employees based on Employee Band level: ");
//       
//       List<Employee> empList=employeeService.getEmployeeByBandLevel("B");
//       
//       for(Employee e:empList) {
//    	   logger.info(e);
//       }
       
//       logger.info("Fetching employee details based on the Email Address: ");
//       String mail="koteswari@gmail.com";
//       Employee e=employeeService.getEmployeeByMail(mail);
//       logger.info(e);
       
       
//       logger.info("Fetching Employee details based on band level and salary: ");
//       String bandLevel="A";
//       double salary=30000.0;
//       Employee e=employeeService.fetchEmployee(bandLevel, salary);
//       logger.info(e);
       
       logger.info("Fetching Employee details based on emial and contact number: ");
       String email="koteswari@gmail.com";
       String number="9908251289";
	   Employee emp=employeeService.getEmployeeByEmailAndNumber(email, number);
	   if(emp==null) {
		   logger.info("Employee not Found");
		   
	   }
	   logger.info(emp);
		
	}

}
