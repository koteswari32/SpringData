package com.infosys.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.domain.Address;
import com.infosys.domain.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	
	//Query based on method name
	Employee findByAddress(Address address);
	
	//Query based on employeeBandLevel
	
	List<Employee> findByEmployeeBandLevel(String employeeBandLevel);
	
	//uncomment the below code if you want use @Query and comment @NamedQuery which is present in Employee Entity class
	//Named parameter approach is used ":"
	//@Query("select emp from Employee emp where emp.employeeEmailId=:emailId")
	
	Employee getEmployeeByEmail(@Param("emailId") String emailId);
	
	@Query("select emp from Employee emp where emp.employeeBandLevel=:bandLevel and emp.employeeSalary=:salary")
	Employee findEmployeeByLevelAndSalary(@Param("bandLevel") String level,@Param("salary") double salary);
	
	
	//Using native sql query here the column names should match with table column names
	
	@Query(value="SELECT * FROM Employee e WHERE e.employeeemailid=:email AND e.employeecontactnumber=:number",nativeQuery=true)
	Employee findEmployeeByMailAndNumber(@Param("email") String mail,@Param("number") String number);
	
	

}
