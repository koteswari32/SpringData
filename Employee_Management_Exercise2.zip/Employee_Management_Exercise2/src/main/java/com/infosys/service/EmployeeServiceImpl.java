package com.infosys.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.domain.Address;
import com.infosys.domain.Employee;
import com.infosys.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeRepository repository;

	//Insert Employee details
	@Override
	public void insertEmployee(Employee employee) {
		System.out.println("Inserting employee");
		repository.save(employee);
		
	}

	//Getting Employee based on Address
	@Override
	public Employee getEmployee(Address address) {
		
		return repository.findByAddress(address);
	}

	//Get all employees and updating the salary based on the employee band level
	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> employees=repository.findAll();
		Employee employee=new Employee();
		List<Employee> emp=new ArrayList<>();
		double empSalary=0;
		for(Employee e:employees) {
			
			if(e.getEmployeeBandLevel().equals("A")) {
				 empSalary=e.getEmployeeSalary()+((e.getEmployeeSalary()*15)/100);
			}
			else if(e.getEmployeeBandLevel().equals("B")) {
				empSalary=e.getEmployeeSalary()+((e.getEmployeeSalary()*10)/100);
			}
			else if(e.getEmployeeBandLevel().equals("C")) {
				empSalary=e.getEmployeeSalary()+((e.getEmployeeSalary()*5)/100);
			}
			e.setEmployeeSalary(empSalary);
			
			emp.add(e);
			
			repository.saveAll(emp);
			
			
		}
		return emp;
	}

	//Getting Employees based on the employeeBandLevel
	@Override
	public List<Employee> getEmployeeByBandLevel(String employeeBandLevel) {
		List<Employee> empList=repository.findByEmployeeBandLevel(employeeBandLevel);
		return empList;
	}

	//Getting employee by email using @Query annotation-uncomment the @Query annotation in EmployeeRepository
	//And comment @NamedQuery from Employee entity class
	@Override
	public Employee getEmployeeByMail(String email) {

		return repository.getEmployeeByEmail(email);
	}

	//Fetching employee details based on salary & band level
	@Override
	public Employee fetchEmployee(String bandLevel, double salary) {
		
		return repository.findEmployeeByLevelAndSalary(bandLevel, salary);
	}
	
	@Override
	public Employee getEmployeeByEmailAndNumber(String emailId,String contactNumber){
		
		return repository.findEmployeeByMailAndNumber(emailId, contactNumber);
		
	}

}
