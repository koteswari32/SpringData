package com.infosys.service;

import com.infosys.domain.Address;

public interface AddressService {
	public void insertAddress(Address address);
}
