package com.infosys.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.domain.Address;
import com.infosys.repository.AddressRepository;

@Service
public class AddressServiceImpl implements AddressService{
	
	@Autowired
	AddressRepository repository;

	@Override
	public void insertAddress(Address address) {

        repository.save(address);
		
	}

}
