package com.infosys.service;

import java.util.List;

import com.infosys.domain.Address;
import com.infosys.domain.Employee;

public interface EmployeeService {

	public void insertEmployee(Employee employee);
	
	public Employee getEmployee(Address address);
	
	public List<Employee> getAllEmployees();
	
	public List<Employee> getEmployeeByBandLevel(String employeeBandLevel);
	
	public Employee getEmployeeByMail(String email);
	
	public Employee fetchEmployee(String bandLevel,double salary);
	
	public Employee getEmployeeByEmailAndNumber(String emailId,String contactNumber);
}
